import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'

export default function Hero() {
  const ref = useRef()

  useEffect(() => {
    gsap.from(ref.current, { opacity: 0, y: 40, duration: 1 })
  }, [])

  return (
    <section className="h-screen flex flex-col justify-center items-center text-center bg-green-50 p-8">
      <h1 ref={ref} className="text-4xl md:text-6xl font-bold text-gray-800">GLOW NATURALLY</h1>
      <p className="mt-4 text-gray-600 max-w-md">Explore our expertly formulated products, crafted to nourish, protect, and rejuvenate your skin.</p>
    </section>
  )
}
import { useState } from 'react'

export default function FAQ() {
  const [active, setActive] = useState(null)
  const data = [
    { q: 'Bio Ingredients?', a: 'All our products are made from 100% bio ingredients.' },
    { q: 'Everything Natural?', a: 'Yes, our formulas use no synthetic materials.' }
  ]

  return (
    <section className="p-8">
      <h2 className="text-xl font-bold mb-4">FAQs</h2>
      {data.map((item, i) => (
        <div key={i} className="mb-2">
          <button className="font-semibold w-full text-left" onClick={() => setActive(active === i ? null : i)}>
            {item.q}
          </button>
          <div className={`transition-all duration-300 ease-in-out ${active === i ? 'max-h-40' : 'max-h-0'} overflow-hidden`}>
            <p className="pl-4 text-sm text-gray-600">{item.a}</p>
          </div>
        </div>
      ))}
    </section>
  )
}
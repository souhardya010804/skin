export default function Testimonial() {
  return (
    <section className="bg-green-100 p-8 text-center">
      <img src="/images/testimonial.jpg" alt="Testimonial" className="mx-auto rounded-lg w-full max-w-xl" />
      <p className="mt-4 text-xl font-medium">Feel Beautiful Inside and Out with Every Product.</p>
      <span className="text-green-700 font-semibold">Aishwarya M</span>
    </section>
  )
}
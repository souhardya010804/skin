export default function Footer() {
  return (
    <footer className="p-8 bg-gray-900 text-white text-center">
      <p>Join The Skincare Community Now.</p>
      <p className="text-sm mt-2">Contact: contact.skincare.com</p>
    </footer>
  )
}
export default function Products() {
  const items = [
    { name: 'AISHWARYA M', image: '/images/product1.jpg' },
    { name: 'AISHWARYA M', image: '/images/product2.jpg' },
    { name: 'AISHWARYA M', image: '/images/product3.jpg' }
  ]

  return (
    <section className="p-8">
      <h2 className="text-2xl font-semibold mb-4">Skincare That Brings Out Your Natural Radiance</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {items.map((item, idx) => (
          <div key={idx} className="bg-white rounded shadow p-4 text-center hover:scale-105 transition">
            <img src={item.image} alt={item.name} className="w-full h-48 object-cover rounded mb-2" />
            <p>{item.name}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
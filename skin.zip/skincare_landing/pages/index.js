import Head from 'next/head'
import Hero from '../components/Hero'
import Products from '../components/Products'
import Testimonial from '../components/Testimonial'
import FAQ from '../components/FAQ'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <>
      <Head>
        <title>Glow Naturally</title>
      </Head>
      <main>
        <Hero />
        <Products />
        <Testimonial />
        <FAQ />
        <Footer />
      </main>
    </>
  )
}